/* file: api.js 

This file handles the api connection and creates the correct urls that are used to call the database and request certain information. The file then uses callbacks to redirect the information to where it needs to go.

Author: Elsa Bergman
*/

function APIConnect() {

	var baseURL = 'http://pub.jamaica-inn.net/fpdb/api.php',
		username = '',
		password = '',
        beer_id = beer_id;
	
    /*creating url with user that is logged in*/
	function constructURL(params) { 
    
        
	var url = baseURL + "?" +'username=' + username + '&' + 'password=' + password;
	
	for (var key in params){
	url = url + '&' + key + '=' + params[key];
	  }
    
	return url;
	}
	/*requesting information from the url and using callback to send it to script_login.js*/
	function request(url, callback) { 
	
	
	var xhr = new XMLHttpRequest();

		
		
	xhr.open('GET', url);
	xhr.onreadystatechange = function() {
		if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
			
			callback(this.responseText);
       
			
			console.log(this.responseText);			
			
	
		}
	};
	
	xhr.send();
	}
	/*fetching the user that is logged in*/
	this.setUser = function(un, pw) {
		username = un;
		password = pw;
	};
	/*fetching all users in the system*/
	this.fetchUsers = function(callback) {
    

		var url = constructURL({action: 'user_get_all'});
		
		request(url, callback);
	
		
	};
    	
}

/* END of file api.js */