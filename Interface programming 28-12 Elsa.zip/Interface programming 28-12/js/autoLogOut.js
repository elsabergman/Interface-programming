var timoutWarning = 60; // Display warning 
var timoutNow = 6000; // Warning has been shown
var logoutUrl = 'login.html'; // URL to logout page.

var warningTimer;
var timeoutTimer;

// Start warning timer.
function StartWarningTimer() {
    warningTimer = setTimeout("IdleWarning()", timoutWarning);
	alert("timer startad")
}
// Reset timers.
function ResetTimeOutTimer() {
    clearTimeout(timeoutTimer);
    StartWarningTimer();
    $("#timeout").dialog('close');
}

// Show idle timeout warning dialog.
function IdleWarning() {
    clearTimeout(warningTimer);
    timeoutTimer = setTimeout("IdleTimeout()", timoutNow);
    $("#timeout").dialog({
        modal: true
    });
    // Add code in the #timeout element to call ResetTimeOutTimer() if
    // the "Stay Logged In" button is clicked
}

// Logout the user.
function IdleTimeout() {
    window.location = logoutUrl;
}

// $(document).on('ready', function()
// {
//    StartWarningTimer()
// });

var idleTime = 0;
$(document).ready(function(){
	var idleInterval = setInterval(timerIncrement,6000);
	$(this).mousemove(function(e){
		idleTime = 0;
	});
	$(this).keypress(function(e){
		idleTime = 0;
	});
});

function timerIncrement(){
	idleTime = idleTime+1;
	lang = localStorage.getItem("lang")
	if (idleTime>4){
		if (lang == "sv"){
			alert ("halloj är du där? Skynda på, bäst före datumet närmar sig")
			
			
		}
		else {
			alert ("Are you there? We know there are a lot of choices, but you need to hurry!")
		
		};
	};
	if (idleTime>10){
		window.location.href="login.HTML";
		localStorage.setItem("username","");
		localStorage.setItem("password","");

	};
}