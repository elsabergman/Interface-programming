$(function (){ 
//Requesting data using jQuery 
var $dept = $('#dept'); //Id of html div
var username = localStorage.getItem('username');
var password = localStorage.getItem('password');
$.ajax({
	method: 'GET',
	url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=iou_get',

success: function(dept) {
console.log(dept);
var lang1 = localStorage.getItem("lang");


//loop for all indices of array payload
$.each(dept.payload, function(i, asset){
	if(lang1=="en"){
		if (asset.assets < 0) {

			$dept.append('<div>You\'re dept is: '+ asset.assets +'</div> ');
			}
		else {
			$dept.append('<div>Congrats!! You don\'t have any dept</div> ');
			};
	}
	else if(lang1=="sv") {
		if (asset.assets < 0) {
			$dept.append('<div>Din Skuld är: '+ asset.assets +'</div> ');
			}
		else {
			$dept.append('<div>Grattis!! Du är skuldfri</div> ');
			};
	}
	else {
		$dept.append('<div>fel med språket'+ lang1 +'är valt</div> ');
	}
 
  });

}
});

//---------------------------- Dept View on Click ---------------------//
var viewDept = ("#viewDept");
$(viewDept).click(function () {
  $($dept).slideToggle();
});


})