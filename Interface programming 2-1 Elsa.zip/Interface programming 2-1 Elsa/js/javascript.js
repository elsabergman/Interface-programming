//==========================================
//Moh:update(23/12); The API that calls each
//person's debt is slow. A "please wait" sign
//should appear until the loading finishes.
//==========================================

$(function (){ 
var MyUserID = '';
var UserID = new Array();
var UserName = new Array();
var FirstName = new Array();
var LastName = new Array();
var Email = new Array();
var Phone = new Array();
var Password = new Array();
var UsersDebt = new Array();
var TrackUser = new Array();
var userasset = '';
//Requesting data using jQuery 
var $allusers = $('#allusers'); //Id of html div
var username = 'jorass';
var password = 'jorass';
$.ajax({
	method: 'GET',
	url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=user_get_all',

success: function(allusers) {


//loop for all indices of array payload
$.each(allusers.payload, function(i, his)
{

  if (his.first_name != '' && his.last_name != '' && his.username != '')
    {
	UserID += his.user_id + ',';
    UserName+=his.username + ',';
    FirstName+=his.first_name + ',';
    LastName+=his.last_name + ',';
    Email+=his.email + ',';
    Phone+=his.phone + ',';
    Password+=his.password + ',';

    }
})
    UserID = UserID.split(',');
    UserName = UserName.split(',');
    FirstName = FirstName.split(',');
    LastName = LastName.split(',');
    Email = Email.split(',');
    Phone = Phone.split(',');
    Password = Password.split(',');
    
/*--- to enable language switching in javascript, we use local storage to find out what language is being used and then translate the words accordingly --*/
    var editString ="Edit User";
    var usernameString = "Username";
    var firstnameString ="First Name";
    var lastnameString="Last Name";
    var phoneString ="Phone";
    var passwordString ="Password";
    var deptString ="Dept";
    var confirmString ="Confirm Changes";
    
   var lang = localStorage.getItem("lang");
       if (lang == "sv") {

             editString ="Ändra användare"
             usernameString = "Användarnamn";
             firstnameString ="Förnamn";
             lastnameString ="Efternamn";
              phoneString ="Telefon";
               passwordString ="Lösenord";
           deptString ="Skuld";
            confirmString ="Bekräfta ändringar"
         } 
    

    //==================================== Old position ===================================
        $("#popupEdit").append('<form action="#" id="Editform" method="post" name="form">'+'<h2>'+editString+'</h2>'
    +'<div id="input">'+           
    '<div id="input_Block"><span id="input_text">'+usernameString+'</span> <input id="UserName" name="name" placeholder="Username" type="text"></div>' +
    '<div id="input_Block"><span id="input_text">'+firstnameString+'</span><input id="FirstName" name="name" placeholder="First Name" type="text"></div>' +
    '<div id="input_Block"><span id="input_text">'+lastnameString+'</span> <input id="LastName" name="name" placeholder="Last Name" type="text"></div>'+
    '<div id="input_Block"><span id="input_text">Email</span><input id="Email" name="name" placeholder="Email" type="text"></div>'+
    '<div id="input_Block"><span id="input_text">'+phoneString+'</span><input id="Phone" name="name" placeholder="Phone" type="text"></div>' +
    '<div id="input_Block"><span id="input_text">'+passwordString+'</span><input id="Password" name="name" placeholder="Password" type="text"></div>'+
    '<div id="input_Block"><span id="input_text">'+deptString+'</span><input id="Dept" name="name" placeholder="Dept" type="text"></div>'+'</div>'+
    '<img id="close" src="http://www.freeiconspng.com/uploads/round-close-button-png-1.png">'+ //onclick="div_hide()">'+ 
   ' <input type = "button" class="btn" id="submit_btn" value='+confirmString+'>' + '</input>' +
    // '<a href="javascript:%20check_empty()" id="submit">Send</a>'+
    '</form>');


    
    function generate_handler(UserName, FirstName, LastName, Email,Phone,Password,Debt) {
    return function(event) { 
       
        MyUserID = UserID;

        div_show(UserName, FirstName, LastName, Email,Phone,Password,Debt);
        
    };
    }


    for(var i = 0; i <= TrackUser.length; i++){

    $('#edit_user'+i).click( generate_handler(UserName[UserName.indexOf(TrackUser[i])],FirstName[UserName.indexOf(TrackUser[i])],LastName[UserName.indexOf(TrackUser[i])],Email[UserName.indexOf(TrackUser[i])],Phone[UserName.indexOf(TrackUser[i])],Password[UserName.indexOf(TrackUser[i])],UsersDebt[i] ) );  
    
    }
    //Function to Hide Popup
        $("#close").click(function() {
            document.getElementById('popupBodyEdit').style.display = "none";
            document.getElementById('popupBodyAdd').style.display = "none";
        })

    //Remove loading_Page div when loading ends
    $("#loading_Page").remove();

    // Validating Empty Field
    $("#submit_btn").click(function() {
    if($('#UserName').val() == '' || $('#FirstName').val() == '' || $('#Password').val() == '' || $('#LastName').val() == '' || $('#Email').val() == ''
       || $('#Phone').val() == '' || $('#Dept').val() == '' ) {
    alert("Fill All Fields !");
    } else {
        $.ajax({
                    method: 'POST',
                    url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=user_edit&new_username=' +
                    $('#UserName').val() + '&new_password=' + $('#Password').val() + '&first_name=' + $('#FirstName').val() + '&last_name=' + $('#LastName').val()
                    + '&email=' + $('#Email').val() + '&phone=' + $('#Phone').val() ,
                    //data: { beer_id: beer.payload.beer_id , amount: beer.payload.amount , price: beer.payload.price },

                    success: function(correct) {
                        for (i = 0; i<TrackUser.length; i++){
                            if (TrackUser[i]=$('#UserName').val()){
                                console.log("found");
                                console.log($('#UserName').val());
                                $("#user"+$('#UserName').val()).text($('#UserName').val());
                                $("#first"+$('#UserName').val()).text($('#FirstName').val());
                                $("#last"+$('#UserName').val()).text($('#LastName').val());
                                $("#debt"+$('#UserName').val()).text($('#Dept').val());
                            }
                        }
                            alert("Changes are successfully saved");
                            document.getElementById('popupBodyEdit').style.display = "none";
                     
                    }})

                     //alert("Form Submitted");   
                    }
                    
    })
//=================================================end=============================================
    

}
})



//Function To Display Popup
function div_show(UserName, FirstName, LastName, Email,Phone,Password,Debt) {
    $("#UserName").prop("readonly", true);
    $('#UserName').val(UserName);
    $('#FirstName').val(FirstName);
    $('#LastName').val(LastName);
    $('#Email').val(Email);
    $('#Phone').val(Phone);
    $('#Password').val(UserName);
    $('#Dept').val(Debt);
    
    
document.getElementById('popupBodyEdit').style.display = "block";
}
$("#closeAdd").click(function() {
            document.getElementById('popupBodyAdd').style.display = "none";
        })

$("#AddUser").click(function (){
    document.getElementById('popupBodyAdd').style.display = "block";
});

$("#Add").click(function (){
    if($('#UserNameAdd').val() == '' || $('#FirstNameAdd').val() == '' || $('#PasswordAdd').val() == '')
    {
      $('.required').show();
    }
    else
    { 
 
            $('#allusers').append(
            '<div class="row" id="'+ $('#UserNameAdd').val() +'">' +
            '<div class="colHeaderEdit" id="'+$('#UserNameAdd').val()+'">'+ $('#FirstNameAdd').val() +'</div> ' +
            '<div class="colHeaderEdit" id="'+$('#UserNameAdd').val()+'">'+ $('#LastNameAdd').val() + '</div>' +     
            '<div class="colHeaderEdit" id="'+$('#UserNameAdd').val()+'">'+ $('#UserNameAdd').val() +'</div> ' + 
            '<div class="colHeaderEdit" id="'+$('#UserNameAdd').val()+'">'+ $('#DeptAdd').val() +'</div> ' +
            '<input type="button" id="edit_user'+$('#UserNameAdd').val()+'"  class="btn" value="EDIT">' + '</input>' +
            '</div>'); 
            alert("Adding complete");
            document.getElementById('popupBodyAdd').style.display = "none";
    }

});

var $dept = $('#dept'); //Id of html div
var username = 'jorass';
var password = 'jorass';
var url1 = 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + username + '&action=iou_get_all';
$.ajax({
    method: 'GET',
    url: url1,
    
success: function(debt) {
    $.each(debt.payload, function(i, userDebt)
        {
            TrackUser += userDebt.username + ',';
            UsersDebt += userDebt.assets + ',';
        
         var lang = localStorage.getItem("lang");
        var EDIT ="EDIT";
       if (lang == "sv") {
           EDIT ="ÄNDRA";
       }

            $allusers.append(
            '<div class="row" id="'+ userDebt.username +'">' +
            '<div class="colHeaderEdit" id="first'+userDebt.username+'">'+ userDebt.first_name +'</div> ' +
            '<div class="colHeaderEdit" id="last'+userDebt.username+'">'+ userDebt.last_name +'</div> ' +      
            '<div class="colHeaderEdit" id="user'+userDebt.username+'">'+ userDebt.username +'</div> ' + 
            '<div class="colHeaderEdit" id="debt'+userDebt.username+'">'+ userDebt.assets +'</div> ' +
            '<input type="button" id="edit_user'+i+'"  class="btn" value='+EDIT+'>' + '</input>' +
            '</div>'); 

        })

    TrackUser = TrackUser.split(',');
    UsersDebt = UsersDebt.split(',');

}
})
//Search function
$( "#search" ).keydown(function() {

    for (i=0; i < TrackUser.length; i++)
    {
        if ($('#search').val() == '')
        {
            $('#'+TrackUser[i]).css("display", "block");
        }
        else
        {

            if ((TrackUser[i].toLowerCase()).includes(($('#search').val()).toLowerCase()) 
                || (FirstName[UserName.indexOf(TrackUser[i])].toLowerCase()).includes(($('#search').val()).toLowerCase()) 
                || (LastName[UserName.indexOf(TrackUser[i])].toLowerCase()).includes(($('#search').val()).toLowerCase())) {
                $('#'+TrackUser[i]).css("display", "block");
            }
            else{
                $('#'+TrackUser[i]).css("display", "none");
            }
        }
    }


});
});

