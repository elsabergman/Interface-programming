/*File: main_script.js

This file handles all controls for buying a beverage. It displays (with help from its' corresponding html file) beverages from the database by categorizing them into alcoholic or non-alcoholic beverages. It creates a cart and it supports adding and removing beverages from the cart. It also enables buying beverages and clearing the cart. 

Authors: Elsa Bergman and Mohammad Alhawwari 
*/
/*--global variables---*/
var total_price = 0;

var purchase_array = new Array;

/*---main ---*/
$(function (){ 
//Requesting data using jQuery 
var $main = $('#main'); //Id of html div
var username = localStorage.getItem('username'); //save username and password to see which ones should see all buttons 
var password = localStorage.getItem('password');
   
/*checks if username is one of the admin names, and if not. It hides the admin buttons. If the user is also an admin, the admin buttons are visible. */
    
     if (username != 'jorass' && username != 'ervtod' && username != 'hirchr' && username != 'saksru' && 
            username != 'svetor') {
         document.getElementById('admin_buttons').style.visibility = 'hidden';
                
     }

$.ajax({
    
    method: 'GET',
    url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=inventory_get',

success: function(main){


//loop for all indices of array payload
    var beer_count = 0; //to make sure the loops stops when we have 16 alcoholic beverages
    var beer_count_nonAlc = 0; //to make sure the loop stops when we have 4 non-alcoholic beverages

  

    /*---make call to fetch user that is logged in--*/
    $(function() {
        $.ajax({
  
    method: 'GET',
    url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=iou_get',

success: function(main) {
    var first_name = main.payload[0].first_name;

     document.querySelector('.login_id').innerHTML = first_name; //display name of person logged in
    
}
        });
    });
    /*--- end call to get logged in user --* 
    /* Get arrays from localStorage. There is one array containing the stock of every beverage, on containing the price of every beverage, one containing the name of every beverage and one containing the ID of every beverage. The Flag array contains information about whether a certain beverage is alcoholic or non alcoholic. */ 

    var BevStock = localStorage.getItem("count").split(',');
    var BevPrice = localStorage.getItem("prices").split(',');
    var BevName = localStorage.getItem("names").split(',');
    var BevID = localStorage.getItem("ID").split(',');
    var Flag = localStorage.getItem("AllBevFlag").split(",");


    /*loop over alcoholic beverages to fill up vending machine*/
    $.each(main.payload, function(i, its)  
           
{     
     if ( (BevStock[i] > 0) && (BevName[i]!= "")  && (beer_count < 16) && Flag[i] == 0) {
         
   
         
         if (BevStock[i] > 10) { // if stock > 10, change stock to display as 10.
             BevStock[i] = 10;
             
         }
         
        
          
      
 //$('#aform') 
      //  .attr("action","main.html") .attr("method","post") //set the form attributes
        //add in all the needed input elements

/*add to vending machine */  
         var left = "";
   var lang = localStorage.getItem("lang");
       if (lang == "en") {
          left = " left";
       }
         else {
             left = " kvar";
         }
         

$main.append( '<div class="small_box" data-value="' + its.beer_id + '">' +
            '<input type="text" class ="values" id="'+its.beer_id+'" value="0"/>' +
            '<div class="small_box_text" id="'+its.beer_id+'Name">'+  BevName[i]+'</div>' +
            '<div class="small_box_text" id="'+its.beer_id+"Stock"+'" data-value="'+ BevStock[i] +'">'+ BevStock[i] + left +'</div> ' +     
            '<div class="small_box_text" id="'+its.beer_id+"Price"+'" data-value="'+ BevPrice[i] +'">'+ BevPrice[i] + " kr"+'</div>'  + 
            '<input type="button" id="'+its.beer_id+'" class="btn_increase" value="+"></input>' +
            '<input type="button" id="'+its.beer_id+'" class="btn_decrease" value="-"></input></div>' ); 
         
             beer_count++;
         localStorage.setItem("count", BevStock);
     
 }
         
     });
 /*--Add non alcoholic beverages to vending machine --*/
  $.each(main.payload, function(i, its) 
         
/*for some reason the position of the box changes when loading in Einbecker Brauherren Alkoholfrei, probably because the name is too long, so therefore this beer has to be exluded from possible beverages that can be displayed in the non-alcoholic section. */
         
{     if ( (BevStock[i] > 0) && (BevName[i]!= "") && (BevName[i]!= "Einbecker Brauherren Alkoholfrei")  && (beer_count_nonAlc < 4) && (Flag[i]==1)) {

  
         if (BevStock[i] > 10) { //If stock > 10, change the stock to display as 10.
             BevStock[i] = 10;
         }
       $('#non-alcohol').append('<div class="small_box" data-value="' + its.beer_id + '">' +
            '<input type="text" class ="values" id="'+its.beer_id+'" value="0"/>' +
            '<div class="small_box_text" id="'+its.beer_id+'Name">'+  BevName[i]+'</div>' +
            '<div class="small_box_text" id="'+BevID[i]+"Stock"+'" data-value="'+ BevStock[i] +'">'+ BevStock[i] + " left"+'</div> ' +     
            '<div class="small_box_text" id="'+its.beer_id+"Price"+'" data-value="'+ BevPrice[i] +'">'+ BevPrice[i] + " kr"+'</div>'  + 
            '<input type="button" id="'+its.beer_id+'" class="btn_increase" value="+"></input>' +
            '<input type="button" id="'+its.beer_id+'" class="btn_decrease" value="-"></input></div>' ); 
    
      beer_count_nonAlc++;

     }
     });
    


 
var decrease_count = 0;
/*----put chosen beer into the cart and update the stock and total accordingly. This is also done in local storage to make sure everything works together when pressing buy or clear as well--*/
    $('.btn_increase').click(function() {
        var id = $(this).attr('id'); //get the ID of the beverage
        var value = parseInt($("#"+id).val()); //get textbox value
       var stockCount = parseInt($("#"+id+"Stock").data('value'));
        var BevStock = localStorage.getItem("count").split(',');
         var BevID = localStorage.getItem("ID").split(',');
        var index = BevID.indexOf(id);
        var theStock = BevStock[index]; // get the stock of the beverage. The stock will have the same index in the BevStock array as the ID has in the BevID array.

    
        var price = $("#"+id+"Price").data('value');
        var beerName = $("#"+id+"Name").text();
        if ((value+1) <= stockCount ) //Make textbox value red if the beverage is in the cart.   
        { 
            $('#'+id).css('color','red');
            BevStock[index] = theStock -1;
            
            if (value == 0) //if the textbox value is 0 and then the + button is pressed, we want to add the beverage to the cart.
            { 
            $("#"+id).val(value+1);
                 $("#"+id+"Stock").text((BevStock[index]) + " left");
                      $("#"+id+"Stock").attr('data-value',(BevStock[index]));
                
             $('#cart').append('<div class="cartrow" id="'+id+'" >' +
                              '<div id="cartname" class="cartcol">'+beerName+'</div>' +
                              '<div id="cartamount" class="'+id+'">x '+(value+1)+'</div>' +
                              '</div>');
            }
            else if (value > 0)
            {      BevStock[index] = theStock -1; //if value > 0, the stock should decrease by one with each button click. 
                $("#"+id).val(value+1);
                $('#cartamount.'+id).text('x '+(value+1));
                       $("#"+id+"Stock").text((BevStock[index]) + " left");
                      $("#"+id+"Stock").attr('data-value',(BevStock[index]));     

            }
            purchase_array += beerName + ","; //The purchase_array keeps track of all beverages in the cart. 
            total_price += +price; // add the price of the beverage to the total
             document.getElementById("total_number").innerHTML = total_price.toPrecision(3); //display the total price.
             localStorage.setItem("count",BevStock); //update local storage with new  stock amount for the beverage.
        }

     
        
        
    });
/*---Remove the chosen beer from the cart and update the stock and total accordingly. This is also done in local storage to make sure everything works together when pressing buy or clear as well.---*/ 
    
    $(function (){ $('.btn_decrease').click(function() {
        var id = $(this).attr('id'); //get textbox value
        var value = parseInt($("#"+id).val()); //get textbox value

        var price = $("#"+id+"Price").data('value'); //price of the beverage that should be removed from the cart
        var beerName = $("#"+id+"Name").text(); //name of the beverage
        
        var BevStock = localStorage.getItem("count").split(','); 
        var BevID = localStorage.getItem("ID").split(','); 
        var index = BevID.indexOf(id); //the index of the id in BevID is the same as the index of the stock in BevStock. 
        var theStock = BevStock[index]; //the stock of the beverage
        
        if ((value-1) >= 0) //the decrease button should only be clickable if the value is 1 or more.
           
        { 
            if(value == 1) // if value is 1, remove all information about beverage from the stock
            {
                 theStock++;
                BevStock[index] = theStock;
            $("#"+id).val(value-1);
            $("#"+id+"Stock").text((theStock) + " left");
            $("#"+id+"Stock").attr('data-value',(theStock));
            $('#'+id+'.cartrow').remove();
            $('#'+id).css('color','black'); //textbox value should be black if beverage not in the cart. 
         
    
            purchase_array = "";
            total_price = 0;
            document.getElementById("total_number").innerHTML = total_price;
                 localStorage.setItem("count",BevStock);
            
            }
            else if (value > 1) //if value > 1, we only want to decrease the number of beverages chosen of a specific kind by one. 
            {  theStock++;
             BevStock[index] = theStock;
                $("#"+id).val(value-1);
                $('#cartamount.'+id).text('x '+(value-1));
                $("#"+id+"Stock").text((theStock) + " left");
                $("#"+id+"Stock").attr('data-value',(theStock));
                //$("#"+id+"Stock").data('value', (stockCount + (value+1)));
                
                 localStorage.setItem("count",BevStock); //update the local storage with the increased stock amount.
                
            total_price -= parseFloat(price); //update the total price 
            document.getElementById("total_number").innerHTML = total_price.toPrecision(3); //display total price
            }
           
        }
              
        
    });
  } ) 

   
    
}
       });
           

});
   

/*--- scrolling feature when clicking to show alcoholic or non alcoholic drinks---*/
function scrollup() { //scrolling to the alcoholic drinks
    
    
$("#Alc_button").click(function(event){     
        event.preventDefault();
        $('.boxes').animate({scrollTop:$("#main").offset().top - 59}, 800); 
       
   
}); 
}
function scrolldown() { //scrolling to the non alcoholic drinks 

    $("#nonAlc_button").click(function(event){     
        event.preventDefault();
        $('.boxes').animate({scrollTop:$("#non-alcohol").offset().top - 59}, 800); 
   
}); 
}

/*---confirm purchase when click on buy. --*/
function confirmPurchase() {

  
    $('.cartrow').remove(); //remove everything from cart 
    purchase_array =""; //reset purchase_array
    total_price = 0; //set total to 0.
     document.getElementById("total_number").innerHTML = total_price; //display total price

    $(".values").val("0"); //all textbox values should be 0 since no beverages are in the cart. 
    $('.values').css({"color":"black"}); //all text box values should be black since no beverages are in the cart 

}
   

/*-- clear button, removes all beers in the cart and resets the number in each box to zero as well as makes the numbers black again. Also sets the total amount to zero --*/
function clearAll(){
var BevName = localStorage.getItem("names").split(',');
purchase_array = purchase_array.split(",");
var BevStock = localStorage.getItem("count").split(',');
var BevID = localStorage.getItem("ID").split(',');
    
/* resets the stock to go back to what it originally was for each beverage that is in the cart */
 for (i=0; i<purchase_array.length-1; i++) {
     var index = BevName.indexOf(purchase_array[i]);
     var stockCount = parseInt($("#"+BevID[index]+"Stock").data('value'));
    BevStock[index]++;
     
    $("#"+BevID[index]+"Stock").text((BevStock[index]) + " left");
 
      localStorage.setItem("count",BevStock); //update local storage with new stock values.
     
 }
        $('.cartrow').remove(); //remove everything from cart 
    purchase_array =""; //reset purchase_array
    total_price = 0; //set total to 0.
     document.getElementById("total_number").innerHTML = total_price; //display total price

    $(".values").val("0"); //all textbox values should be 0 since no beverages are in the cart. 
    $('.values').css({"color":"black"}); //all text box values should be black since no beverages are in the cart 

    
}

/*--- if the customer clicks on the log out button in the "purchase confirmed2" popup box, the user should be redirected to the login page and the local storage needs to forget what user was most recently logged in --*/

function logout() {
    window.location = 'login.HTML';
    localStorage.setItem("username","");
    localStorage.setItem("password", "");
}


