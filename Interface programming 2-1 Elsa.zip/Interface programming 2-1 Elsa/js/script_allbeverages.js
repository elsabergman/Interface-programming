/*--global variables --*/

var my_beer_id ="";
var beer_ids = new Array();

/* Get arrays from localStorage. There is one array containing the stock of every beverage, on containing the price of every beverage, one containing the name of every beverage and one containing the ID of every beverage. The Flag array contains information about whether a certain beverage is alcoholic or non alcoholic. */ 

var AllBevNames = localStorage.getItem("names").split(',');
var AllBevStock = localStorage.getItem("count").split(',');
var AllBevPrices = localStorage.getItem("prices").split(',');
var Flag = localStorage.getItem("AllBevFlag").split(",");

/*--- all beverages file begins  ---*/
$(function (){ 
   
    
//Requesting data using jQuery 
var $allBeverages = $('#allBeverages'); //Id of html div
var username = localStorage.getItem('username');

var password = localStorage.getItem('password');
    
        
/*checks if username is one of the admin names, and if not. It hides the admin buttons. If the user is also an admin, the admin buttons are visible. */
    
     if (username != 'jorass' && username != 'ervtod' && username != 'hirchr' && username != 'saksru' &&
            username != 'svetor') {
        document.getElementById('admin_buttons').style.visibility = 'hidden';
         
     }
   
/*-- make call to fetch all inventory in the system --*/
$.ajax({
	method: 'GET',
	url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=inventory_get',

success: function(allBeverages) {
      $(function() {
        $.ajax({
  
	method: 'GET',
	url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=iou_get',

success: function(main) {
    var first_name = main.payload[0].first_name;

     document.querySelector('.login_id').innerHTML = first_name; //display name of person logged in.
 
 ;
}
        });
    });

//loop for all indices of array payload
   
$.each(allBeverages.payload, function(i, her)
{
     
    
    beer_ids += her.beer_id + ','; //add beer_ids to array.
    
  });
    


    beer_ids = beer_ids.split(',');

    /*-- add beverages to table along with a button that enables editing the information of every beverage --*/
    
    for (i=0; i<allBeverages.payload.length; i++) {
        
    var lang = localStorage.getItem("lang"); //Checking what language the button text should be in
        var EDIT ="EDIT";
       if (lang == "sv") {
           EDIT ="ÄNDRA";
       }   
    $allBeverages.append('<div class="row " >' + 
 			'<div class="col" id="'+beer_ids[i]+'">'+ AllBevNames[i] +'</div> ' +
 			'<div class="col" id="'+beer_ids[i]+"S"+'">'+ AllBevStock[i] +'</div> ' +  	
 			'<div class="col"id="'+beer_ids[i]+"P"+'">'+ AllBevPrices[i] +'</div>' + '<input type="button" id="edit_bev'+i+'" class="editbtn" value='+EDIT+'>' + '</input>' + '</div>' ); 
   
    }
    /*-- add popup box to each beverage. This popup box becomes visible when the user clicks on the edit button and it displays all information about a certain beverage --*/
    
    $("#popupEdit").append('<form name="form" id="Editform" method="post" >' +
                            '<h2>Edit Beverages</h2>' +
                            '<div id="input">' +  
                            '<input id="name_bev" name="name" value ="" type="text">' +  '<br>'
                            + '<input id="stock" name="stock"  type="text">'
                            +    '<input id="price" name="price" value = "price" type="text">' + '</div>' + 

                            '<img id="close" class ="close" src="http://www.freeiconspng.com/uploads/round-close-button-png-1.png" onclick="div_hide()">'
                           
                           + ' <input type = "button" class="btn" id="submit_btn" onclick = check_empty() value = "confirm changes">' + '</input>' +  '</form>');
    
/*-- to make buttons work in a loop, with a different id to every EDIT button --*/
    
function generate_handler(the_name, the_count, the_price, the_beer_id) {
    return function(event) { 
        
        my_beer_id = the_beer_id;
        div_show(the_name, the_count, the_price, the_beer_id); //send relevant infomation about the beverage that the user wants to edit to the function that displays the popup box. 
        
    };
}
for(var i = 0; i <= allBeverages.payload.length; i++){
   
    
   $('#edit_bev'+i).click( generate_handler( AllBevNames[i],AllBevStock[i],AllBevPrices[i],beer_ids[i]) );  
    
}
    
}
});  
});


/*-- Checking if some fields are empty, and if not call update_table to update the table with the correct information --*/
function check_empty() {
if (form.name.value == "" || form.stock.value == "" || form.price.value == "") {
alert("Fill All Fields ! // Fyll i alla rader!");
} else {

update_table();
}
}

//Function To Display Popup with pre filled values
function div_show(name, count, price, beer_id) {

    $('#name_bev').val(name);
    $('#stock').val(count);
    $('#price').val(price);

document.getElementById('popupBody').style.display = "block";

}
//Function to Hide Popup
function div_hide(){
document.getElementById('popupBody').style.display = "none";
}
/*---- getting the table to update with the values set in the form --*/
function update_table() {

    var index = beer_ids.indexOf(my_beer_id);
    /*-- getting the updated values from the popup box that were edited by the admin --*/    
    the_stock= form.stock.value;
    the_name = form.name.value;
    the_price = form.price.value;
    
    /*--displaying the updated information in the table--*/
    document.getElementById(beer_ids[index]).innerHTML = the_name;
    document.getElementById(beer_ids[index]+"S").innerHTML = the_stock;
    document.getElementById(beer_ids[index]+"P").innerHTML = the_price;

/*-- updating local storage arrays with updated values--*/
    AllBevStock[index] = the_stock
    AllBevNames[index] = the_name;
    AllBevPrices[index] = the_price
     localStorage.setItem("count", AllBevStock);
    localStorage.setItem("prices", AllBevPrices);
    localStorage.setItem("names", AllBevNames);

    div_hide(); //Hide popup box after clicking on confirm changes
    my_beer_id = "";
  

   
  
    
   
}
    
