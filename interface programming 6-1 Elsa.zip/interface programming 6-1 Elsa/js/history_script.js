/*---history 
Purpose of this file:
1. Get user's History from the database and add it to html page.
2. Search histroy of user by date or beverage.

Dependencies: The file uses username and password from the local storage which are saved from the login page.

Author: Mohammad Alhawwari.
---*/
$(function (){ 
var iLength = 0;
var hDate = new Array();
var hDrink = new Array(); 
var $history = $('#history'); //Id of html div
var username = localStorage.getItem('username');

var password = localStorage.getItem('password');
         
/*checks if username is one of the admin names, and if not. It hides the admin buttons. If the user is also an admin, the admin buttons are visible. */
    
     if (username != 'jorass' && username != 'ervtod' && username != 'hirchr' && username != 'saksru' &&
            username != 'svetor') {
        document.getElementById('admin_buttons').style.visibility = 'hidden';
       
         
     }
//Function to get History from api and add it to html table   
$.ajax({
	method: 'GET',
	url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=purchases_get',

success: function(history) {
    
     var lang = localStorage.getItem("lang"); //To check what language placeholder text should be in
       if (lang == "sv") { 
$('#search').attr('placeholder','Sök dryck eller datum...');
       };
    
      $(function() {
        $.ajax({
  
	method: 'GET',
	url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=iou_get',

success: function(main) {
    var first_name = main.payload[0].first_name;
    var last_name = main.payload[0].last_name;
     document.querySelector('.login_id').innerHTML = first_name;

    
}
        });
    });


//loop for all indices of array payload
$.each(history.payload, function(i, his)
{
$history.append('<div class="row" id="'+ i +'">' +
 			'<div class="col">'+ his.timestamp +'</div> ' +
 			'<div class="col">'+ his.namn +'</div> ' +  	
 			'<div class="col">'+ his.price +'</div> ' + 
			'</div> '); 
hDate += his.timestamp + ',';
hDrink+= his.namn + ',';
iLength = i;
  });
hDate = hDate.split(',');
hDrink = hDrink.split(',');
}
});

//Search function
$( "#search" ).keydown(function() {
    jQuery(function ($) {
    for (i=0; i <= iLength; i++)
    {
        console.log(hDrink[i]);
        if ($('#search').val() == '')
        {
            $("#"+ i).css("display", "block");
        }
        else
        {

            if ((hDrink[i].toLowerCase()).includes(($('#search').val()).toLowerCase()) 
                || (hDate[i].toLowerCase()).includes(($('#search').val()).toLowerCase())) {
                $("#"+ i).css("display", "block");
            }
            else{
                
                $("#" + i).css("display", "none");
            }
        }
    }
    
})


});
});