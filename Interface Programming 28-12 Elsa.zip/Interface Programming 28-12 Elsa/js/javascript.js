//==========================================
//Moh:update(23/12); The function that gets 
//the debt is very slow. Should figure out
//another way to load it.
//==========================================

$(function (){ 
var MyUserID = '';
var UserID = new Array();
var UserName = new Array();
var FirstName = new Array();
var LastName = new Array();
var Email = new Array();
var Phone = new Array();
var Password = new Array();
var userasset = '';
//Requesting data using jQuery 
var $allusers = $('#allusers'); //Id of html div
var username = 'jorass';
var password = 'jorass';
$.ajax({
	method: 'GET',
	url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=user_get_all',

success: function(allusers) {


//loop for all indices of array payload
$.each(allusers.payload, function(i, his)
{
    UserID += his.user_id + ',';
    UserName+=his.username + ',';
    FirstName+=his.first_name + ',';
    LastName+=his.last_name + ',';
    Email+=his.email + ',';
    Phone+=his.phone + ',';
    Password+=his.password + ',';
    
//Requesting data using jQuery 
var $dept = $('#dept'); //Id of html div
var username = his.username;
var password = his.password;
var url1 = 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + username + '&action=iou_get';
$.ajax({
	method: 'GET',
	url: url1,
    
success: function(debt, allusers) {

   
    
//loop for all indices of array payload
$.each(debt.payload, function(x, userDebt)
{

	
    
    if (his.first_name != '' && his.last_name != '' && his.username != '')
    {

    userasset = userDebt.assets;
    $allusers.append(
            '<div class="row">' +
            '<div class="colHeaderEdit" id="'+his.user_id+'">'+ his.first_name +'</div> ' +
            '<div class="colHeaderEdit" id="'+his.user_id+'">'+ his.last_name +'</div> ' +      
            '<div class="colHeaderEdit" id="'+his.user_id+'">'+ his.username +'</div> ' + 
            '<div class="colHeaderEdit" id="'+his.user_id+'">'+ userasset +'</div> ' +
            '<input type="button" id="edit_user'+i+'"  class="btn" value="EDIT">' + '</input>' +
            '</div>'); 
    }
	});
    
  }

});
    
    /*if (his.first_name != '' && his.last_name != '' && his.username != ''){    
    $allusers.append(
            '<div class="row">' +
 			'<div class="colHeaderEdit" id="'+his.user_id+'">'+ his.first_name +'</div> ' +
 			'<div class="colHeaderEdit" id="'+his.user_id+'">'+ his.last_name +'</div> ' +  	
 			'<div class="colHeaderEdit" id="'+his.user_id+'">'+ his.username +'</div> ' + 
            '<div class="colHeaderEdit" id="'+his.user_id+'">'+ userasset +'</div> ' +
            '<input type="button" id="edit_user'+i+'"  class="btn" value="EDIT">' + '</input>' +
            '</div>'); 
            }*/
  });
    UserID = UserID.split(',');
    UserName = UserName.split(',');
    FirstName = FirstName.split(',');
    LastName = LastName.split(',');
    Email = Email.split(',');
    Phone = Phone.split(',');
    Password = Password.split(',');
    
    $("#popupEdit").append('<form action="#" id="Editform" method="post" name="form">'+'<h2>Edit User</h2>'
    +'<div id="input">'+           
    '<input id="Username" name="name" placeholder="Username" type="text">' +'<br>'+
    '<input id="FirstName" name="name" placeholder="First Name" type="text">' + '<br>'+
    '<input id="LastName" name="name" placeholder="Last Name" type="text">'+'<br>'+
    '<input id="Email" name="name" placeholder="Email" type="text">'+ '<br>'+
    '<input id="Phone" name="name" placeholder="Phone" type="text">' +'<br>'+
    '<input id="Password" name="name" placeholder="Password" type="text">'+'<br>'+
    '<input id="Dept" name="name" placeholder="Dept" type="text">'+'<br>'+'</div>'+
    '<img id="close" src="http://www.freeiconspng.com/uploads/round-close-button-png-1.png" onclick="div_hide()">'+
    '<a href="javascript:%20check_empty()" id="submit">Send</a>'+
    '</form>');
    
    function generate_handler(UserName, FirstName, LastName, Email,Phone,Password) {
    return function(event) { 
       
        MyUserID = UserID;
        div_show(UserName, FirstName, LastName, Email,Phone,Password);
        
    };
}
for(var i = 0; i <= allusers.payload.length; i++){
   

   $('#edit_user'+i).click( generate_handler(UserName[i],FirstName[i],LastName[i],Email[i],Phone[i],Password[i] ) );  
    
}
    
}
});


// Validating Empty Field
function check_empty() {
if (document.getElementById('name').value == "" || document.getElementById('stock').value == "" || document.getElementById('price').value == "") {
alert("Fill All Fields !");
} else {
document.getElementById('Editform').submit();
alert("Form Submitted");
}
}
//Function To Display Popup
function div_show(UserName, FirstName, LastName, Email,Phone,Password) {
    $('#UserName').val(UserName);
    $('#FirstName').val(FirstName);
    $('#LastName').val(LastName);
    $('#Email').val(Email);
    $('#Phone').val(Phone);
    $('#Password').val(Password);
    
    
    
document.getElementById('popupBody').style.display = "block";
}
//Function to Hide Popup
function div_hide(){
document.getElementById('popupBody').style.display = "none";
}

});