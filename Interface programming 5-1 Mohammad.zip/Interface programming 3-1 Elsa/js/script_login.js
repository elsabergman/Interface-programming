/*
File: script_login.js 

This file handles all controls necessary when logging into the systems. For example, the  checking of the username and password to see if they are correct. In this fil
all arrays with information about the beverages are created and set into local storage, in order to enable the usage of them in other files. This file calls   api_login.js to get the necessary information from the database.

Author: Elsa Bergman 

*/

AllBevNames = new Array();
AllBevStock = new Array();
AllBevPrices = new Array();
AllBevID = new Array();
var lang = localStorage.getItem("lang"); //To check what language placeholder text should be in
       if (lang == "sv") { 
$('#userid').attr('placeholder','Användarnamn');
$('#pswrd').attr('placeholder','Lösenord');
       };
function connectionAPI(userID,password) {
var apiTemp = new APIConnect(), //Create temporary api connection in order to fetch all users in the system and later be able to compare them to the person that logged in. 
    userID = userID,
    password = password,
    btn = document.getElementById("loginform");
   apiTemp.setUser('jorass', 'jorass');
    localStorage.setItem('username',"");
    localStorage.setItem('password',"");

    check(apiTemp, userID, password);
}


function check(apiTemp,password, userID){
    var Pass = password;
    var username = userID;
    api = new APIConnect();
    apiTemp.fetchUsers(function(usr) { //Fetching all users with jorass log in since she is an admin and therefore can fetch all users. 

var json = JSON.parse(usr);
var payload = json.payload;
var correct = false;
for (i=0; i<payload.length; i++) {
    var name = payload[i].username;
    
    if (name == username && Pass == username) { //Comparing the person that logged in to the people fetched from the database to see if the person should be logged in or denied access. 
         api.setUser(userID, password);
        localStorage.setItem('username',username);
        localStorage.setItem('password',Pass);
        correct = true;
        //If admin, open the extended main page
       
            window.location = 'main.HTML';
    
    }
    
   
}
 
   if (!correct || username=="" ||Pass=="") { //If password or username wasn't correct or some fields were left empty, an alert box pops up and the page reloads so that the user can try again.
    var lang = localStorage.getItem("lang");
       if (lang == "en") {
          alert("The username and/ or password you entered isn't correct.");
     }
       else {
           alert("Användarnamnet och/eller lösenordet är inte korrekt. ");
       }
   
   
       window.location.reload();
    
  }
    });
                   }
                
function docLoaded(fn) {
	if (document.readyState !== 'loading'){
		fn();
	} else {
		document.addEventListener('DOMContentLoaded', fn);
		
	}
}

function pageLoaded(form) {
    var userID = form.userid.value; //Get username and password that the user enterted from the form
    var password = form.pswrd.value;
    
    connectionAPI(userID,password); 
    

}
/*----load arrays and put into local storage ---*/

$(function (){ 
var $login = $('#login'); //Id of html div
$.ajax({
	method: 'GET',
	url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=jorass' + '&password=jorass' + '&action=inventory_get', //get all inventory from database

/*-- load all necessary information into different arrays. One for all beverage names, one for the stock of each beverage, one for the price of each beverage and one for the ID of each beverage */
success: function(login) {
$.each(login.payload, function(i, his)
{
    AllBevNames += his.namn + ','; 
    AllBevStock += his.count +',';
    AllBevPrices += his.price + ',';
    AllBevID += his.beer_id + ',';
    
    
    
});
    AllBevFlag = new Array(); // An array to keep track of what beverages are alcoholic and what beverages are non-alcoholic. 


    $(function() {
    $.each(login.payload, function(i, its)
{ 
    $.ajax({
    
	method: 'GET',
	url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + 'jorass' + '&password=' + 'jorass' + '&action=beer_data_get&beer_id=' + its.beer_id, //call to the database with each beer id to check which beverages contain alcohol and which beverages do not. 
        
success: function(login) {
   
  var alcohol = login.payload[0].alkoholhalt;
    console.log(login.payload[0].alkoholhalt);
  if(  (alcohol == "0%" || alcohol == "0.5%") )  {
      
      AllBevFlag[i] = 1; //if 1 --> non-alcoholic
      
  }else {
          AllBevFlag[i] = 0; // if 0 --> alcoholic
      }


  /*load the array into local storage so that it can be used in other files*/
      localStorage.setItem("AllBevFlag", AllBevFlag);

}
       
    });
            
    });

      
        
      });
    /* load all arrays into local storage so that we can use them in every other file*/
    localStorage.setItem('count', AllBevStock);
    localStorage.setItem('prices',AllBevPrices);
    localStorage.setItem('names', AllBevNames);
     localStorage.setItem('ID', AllBevID);
   
}
});
});

