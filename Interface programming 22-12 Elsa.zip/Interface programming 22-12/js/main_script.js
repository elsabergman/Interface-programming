
/*--global variables---*/
var total_price = 0;
var name ="";
var my_beer_id = "";
var purchase_array = new Array;

  var beer_id = new Array();

/*---main ---*/
$(function (){ 
//Requesting data using jQuery 
var $main = $('#main'); //Id of html div
var username = localStorage.getItem('username'); //save username and password to see which ones should see all buttons 
var password = localStorage.getItem('password');
    
/*checks if username is one of the admin names, and if not. It hides the admin buttons. If the user is also an admin, the admin buttons are visible. */
    
     if (username != 'jorass' && username != 'ervtod' && username != 'hirchr' && username != 'saksru' && 
            username != 'svetor') {
         document.getElementById('admin_buttons').style.visibility = 'hidden';
        // alert(username);
        
         
     }

$.ajax({
    
    method: 'GET',
    url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=inventory_get',

success: function(main){
//console.log(history);

//loop for all indices of array payload
    var beer_count = 0; //to make sure the loops stops when we have 17 beers
    var beer_count_nonAlc = 0;
    var names = new Array();
    var prices = new Array();
    var amounts = new Array();
  

    /*---make call to fetch user that is logged in--*/
    $(function() {
        $.ajax({
  
    method: 'GET',
    url: 'http://pub.jamaica-inn.net/fpdb/api.php?username=' + username + '&password=' + password + '&action=iou_get',

success: function(main) {
    var first_name = main.payload[0].first_name;
    var last_name = main.payload[0].last_name;
     document.querySelector('.login_id').innerHTML = first_name // "+ last_name;
    
}
        });
    });
    /*--- end call to get logged in user --* 
    /* Get arrays from localStorage */ 

    var BevStock = localStorage.getItem("count").split(',');
    var BevPrice = localStorage.getItem("prices").split(',');
    var BevName = localStorage.getItem("names").split(',');
    var BevID = localStorage.getItem("ID").split(',');
    var Flag = localStorage.getItem("AllBevFlag").split(",");


    /*loop over alcoholic beverages to fill up vending machine*/
    $.each(main.payload, function(i, its)  
           
{     
     if ( (BevStock[i] > 0) && (BevName[i]!= "")  && (beer_count < 16) && Flag[i] == 0) {
         
         names += BevName[i] + ',' ;
         prices += BevPrice[i] +',';
         beer_id += its.beer_id +',';
         
         if (BevStock[i] > 10) {
             BevStock[i] = 10;
             
         }
          amounts += BevStock[i] + ',';
        
          
      
 $('#aform') 
        .attr("action","main.html") .attr("method","post") //set the form attributes
        //add in all the needed input elements

/*add to vending machine */  
$main.append( '<div class="small_box" data-value="' + its.beer_id + '">' +
            '<input type="text" class ="values" id="'+its.beer_id+'" value="0"/>' +
            '<div class="small_box_text" id="'+its.beer_id+'Name">'+  BevName[i]+'</div>' +
            '<div class="small_box_text" id="'+its.beer_id+"Stock"+'" data-value="'+ BevStock[i] +'">'+ BevStock[i] + " left"+'</div> ' +     
            '<div class="small_box_text" id="'+its.beer_id+"Price"+'" data-value="'+ BevPrice[i] +'">'+ BevPrice[i] + " kr"+'</div>'  + 
            '<input type="button" id="'+its.beer_id+'" class="btn_increase" value="+"></input>' +
            '<input type="button" id="'+its.beer_id+'" class="btn_decrease" value="-"></input></div>' ); 
             beer_count++;
         localStorage.setItem("count", BevStock);
     
 }
         
     });
 
  $.each(main.payload, function(i, its)  
           
{     if ( (BevStock[i] > 0) && (BevName[i]!= "")  && (beer_count_nonAlc < 4) && (Flag[i]==1)) {

    /*append non alcoholic beverages*/
         if (BevStock[i] > 10) {
             BevStock[i] = 10;
         }
       $('#non-alcohol').append('<div class="small_box" data-value="' + its.beer_id + '">' +
            '<input type="text" class ="values" id="'+its.beer_id+'" value="0"/>' +
            '<div class="small_box_text" id="'+its.beer_id+'Name">'+  BevName[i]+'</div>' +
            '<div class="small_box_text" id="'+BevID[i]+"Stock"+'" data-value="'+ BevStock[i] +'">'+ BevStock[i] + " left"+'</div> ' +     
            '<div class="small_box_text" id="'+its.beer_id+"Price"+'" data-value="'+ BevPrice[i] +'">'+ BevPrice[i] + " kr"+'</div>'  + 
            '<input type="button" id="'+its.beer_id+'" class="btn_increase" value="+"></input>' +
            '<input type="button" id="'+its.beer_id+'" class="btn_decrease" value="-"></input></div>' ); 
    
      beer_count_nonAlc++;

    
         beer_id += its.beer_id +',';
     }
     });
    


 
     names = names.split(",");
 
    amounts = amounts.split(",");

    
    prices = prices.split(",");
 
var decrease_count = 0;
/*----put chosen beer into the cart and update the stock and total accordingly. This is also done in local storage to make sure everything works together when pressing buy or clear as well--*/
    $('.btn_increase').click(function() {
        var id = $(this).attr('id');
        var value = parseInt($("#"+id).val()); //get textbox value
      // var stockCount = parseInt($("#"+id+"Stock").data('value'));
        var BevStock = localStorage.getItem("count").split(',');
         var BevID = localStorage.getItem("ID").split(',');
        var index = BevID.indexOf(id);
        var theStock = BevStock[index];

        
        var price = $("#"+id+"Price").data('value');
        var beerName = $("#"+id+"Name").text();
        if ((value+1) <= theStock )    
        {
            $('#'+id).css('color','red');
            BevStock[index] = theStock -1;
            
            if (value == 0)
            { 
            $("#"+id).val(value+1);
                 $("#"+id+"Stock").text((BevStock[index]) + " left");
                      $("#"+id+"Stock").attr('data-value',(BevStock[index]));
              //  $("#"+id+"Stock").text((stockCount - (value+1)) + " left");
               // $("#"+id+"Stock").attr('data-value',(stockCount - (value+1)));
             $('#cart').append('<div class="cartrow" id="'+id+'" >' +
                              '<div id="cartname" class="cartcol">'+beerName+'</div>' +
                              '<div id="cartamount" class="'+id+'">x '+(value+1)+'</div>' +
                              '</div>');
            }
            else if (value > 0)
            {      BevStock[index] = theStock -1;
                $("#"+id).val(value+1);
                $('#cartamount.'+id).text('x '+(value+1));
                       $("#"+id+"Stock").text((BevStock[index]) + " left");
                      $("#"+id+"Stock").attr('data-value',(BevStock[index]));     

            }
            purchase_array += beerName + ",";
            total_price += +price;
             document.getElementById("total_number").innerHTML = total_price;
             localStorage.setItem("count",BevStock);
        }

     
        
        
    });
/*---Remove the chosen beer from the cart and update the stock and total accordingly. This is also done in local storage to make sure everything works together when pressing buy or clear as well.---*/ 
    $(function (){ $('.btn_decrease').click(function() {
        var id = $(this).attr('id');
        var value = parseInt($("#"+id).val()); //get textbox value
   //    var stockCount = parseInt($("#"+id+"Stock").data('value'));
   //     var decrease_count = stockCount - (value); 
        var price = $("#"+id+"Price").data('value');
        var beerName = $("#"+id+"Name").text();
        var BevStock = localStorage.getItem("count").split(',');
        var BevID = localStorage.getItem("ID").split(',');
        var index = BevID.indexOf(id);
        var theStock = BevStock[index];
        
        if ((value-1) >= 0)
        { 
            if(value == 1)
            {
                 theStock++;
                BevStock[index] = theStock;
            $("#"+id).val(value-1);
            $("#"+id+"Stock").text((theStock) + " left");
            $("#"+id+"Stock").attr('data-value',(theStock));
            $('#'+id+'.cartrow').remove();
            $('#'+id).css('color','black');
         
    
            purchase_array = "";
            total_price = 0;
            document.getElementById("total_number").innerHTML = total_price;
                 localStorage.setItem("count",BevStock);
            
            }
            else if (value > 1)
            {  theStock++;
             BevStock[index] = theStock;
                $("#"+id).val(value-1);
                $('#cartamount.'+id).text('x '+(value-1));
                $("#"+id+"Stock").text((theStock) + " left");
                $("#"+id+"Stock").attr('data-value',(theStock));
                //$("#"+id+"Stock").data('value', (stockCount + (value+1)));
                
                 localStorage.setItem("count",BevStock);
                
            total_price -= parseFloat(price);
            document.getElementById("total_number").innerHTML = total_price.toPrecision(3);
            }
           
        }
              
        
    });
  } ) 

   
    
}
       });
           

});
   
/*--- scrolling feature when clicking to show alcoholic or non alcoholic drinks---*/
function scrollup() {
$("#Alc_button").click(function(event){     
        event.preventDefault();
        $('html,body').animate({scrollTop:$("#main").offset().top - 59}, 800); 
       
   
}); 
}
function scrolldown() {
    $("#nonAlc_button").click(function(event){     
        event.preventDefault();
        $('html,body').animate({scrollTop:$("#non-alcohol").offset().top - 59}, 800); 
   
}); 
}

/*---confirm purchase. When click on BUY, the user can see what he/she bought, what the total was as well as new credit.--*/
function confirmPurchase() {

    
    $('.cartrow').remove();
    purchase_array ="";
    total_price = 0;
     document.getElementById("total_number").innerHTML = total_price; 

    $(".values").val("0");
    $('.values').css({"color":"black"});

    


    
}




          

/*-- clear button, removes all beers in the cart and resets the number in each box to zero as well as makes the numbers black again. Also sets the total amount to zero --*/
function clearAll(){
var BevName = localStorage.getItem("names").split(',');
purchase_array = purchase_array.split(",");
var BevStock = localStorage.getItem("count").split(',');
var BevID = localStorage.getItem("ID").split(',');
 for (i=0; i<purchase_array.length-1; i++) {
     var index = BevName.indexOf(purchase_array[i]);
     var stockCount = parseInt($("#"+BevID[index]+"Stock").data('value'));
    BevStock[index]++;
     
    $("#"+BevID[index]+"Stock").text((BevStock[index]) + " left");
 
      localStorage.setItem("count",BevStock);
     
 }
      $('.cartrow').remove();
    purchase_array ="";
    total_price = 0;
     document.getElementById("total_number").innerHTML = total_price; 

    $(".values").val("0");
      $('.values').css({"color":"black"});  
    
}

function logout() {
    window.location = 'login.HTML';
    localStorage.setItem("username","");
    localStorage.setItem("password", "");
}