/*
File: translations.js 

This file handles all translations on the different pages. It includes a dictionary of the translatable words called langs

Author: Teddy Wickstrom

*/


var langs ={
 history: {
  en: "History",
  sv: "Historik"
 },
 beverages: {
  en: "Beverages",
  sv: "Drycker"
 },
 beverage: {
  en: "Beverage",
  sv: "Dryck"
 },
  amount: {
  en: "Amount",
  sv: "Mängd"
 },
  price: {
  en: "Price (kr)",
  sv: "Pris (kr)"
 },
 purchaseHistory: {
  en: "Purchase History",
  sv: "Köp Historik"
 }, 
 Total: {
  en: "Your total",
  sv: "Summan"
 },
 manageBeverages: {
  en: "Manage Beverages",
  sv: "Hantera Drycker"
 },
 
 chooseTypeBeer: {
  en: "alcoholic/non-alcoholic",
  sv: "Välj ölsort"
 },
  date: {
  en: "Date",
  sv: "Datum"
 },
 theseChoicesContainAlcohol: {
  en: "These choices contain alcohol",
  sv: "Dessa alternativ innehåller Alkohol"
 },
 yourCart: {
  en: "Your Cart",
  sv: "Din vagn"
 },
 yourtotal: {
	en: "Your Total:",
	sv: "Summan:"
 },
 NonAlcoholic: {
  en: "These choices are non-alcoholic",
  sv: "Alkoholfira alternativ"
 },
 manageUsers: {
	en: "Manage Users",
	sv: "Hantera Användare"
 },
 buy: {
	 en: "Buy",
	 sv: "Köp"
 },
 clear:{
	 en: "Clear",
	 sv: "Rensa"
 },
 logOut:{
	 en: "Log Out",
	 sv: "logga ut"
 },
 alcohol:{
	 en: "Alcohol",
	 sv: "Alkohol"
 },
 alcoholfree:{
	 en: "Alcohol free",
	 sv: "Alkoholfria"
 },
 changebeverages:{
	 en: "Change beverages",
	 sv: "Ändra Drycker"
 },
 debt:{
	 en: "Debt",
	 sv: "Skuld"
 },
 inventory:{
	 en: "Inventory",
	 sv: "Lager"
 },
 stock:{
	 en: "Vending Machine",
	 sv: "Maskinen"
 },
 updateStock:{
	 en: "Update Vending Machine Setup",
	 sv: "Uppdatera maskinens innehåll"
 },
 cancel1:{
	 en: "Cancel",
	 sv: "Avbryt"
},
 userName:{
	 en: "Username",
	 sv: "Användarnamn"
},
 lastName:{
	 en: "Last Name",
	 sv: "Efternamn"
},
 firstName:{
	 en: "First Name",
	 sv: "Förnamn"
},
    login: {
    en: "Log In",
    sv: "Logga in"
},
    logout: {
    en: "Log Out",
    sv: "Logga ut"
},

inventory: {
    en: "Inventory",
    sv: "Inventarie"
},
    vendingMachine: {
        en: "Vending Machine",
        sv: "I maskinen"
    },
    
    purchaseConfirmed: {
    en:"Purchase Confirmed!",
    sv:"Köp Bekräftat!"
},
    purchaseInfo: {
        en: "Click on the 'Log out' button to log out or X to remain logged in",
        sv: "Klicka på 'Logga ut' för att logga ut eller på X för att stanna på sidan"
    },
    loadingUsers: {
        en: "Loading Users... Please Wait",
        sv: "Laddar användare... Vänligen vänta"
    },
    addUser: {
        en: "Add User",
        sv: "Lägg till ny användare"
    },
    fillAllFields: {
        en: " Fields with * must be filled",
        sv: "Fält med * måste fyllas i"
    },
    add: {
        en: "Add",
        sv:"Lägg till"
    
},
    phone: {
        en: "Phone",
        sv:"Telefon"
    },
    password: {
        en: "Password",
        sv: "Lösenord"
    },
    NotRegistered: {
        en: "Not registered to the system?",
        sv: "Är du inte en registrerad användare?"
    },
    ContactAdmin: {
        en: "Contact one of the administrators!",
        sv: "Kontakta en av administratörerna!"
    },
    search: {
        en: "Search for user:",
        sv: "Sök användare: "
        
    },
    Content: {
    en: "Update the vending machine's content",
    sv: "Uppdatera maskinens innehåll"
    
    
},
    h2Content: {
        en: "Drag the prefered beverages from 'Inventory' to 'Vending Mahcine'",
        sv: "Dra de önskade dryckerna från 'Inventarie' till 'I maskinen'"
    }
}

function get_translation(lang, key){ //this function that searches the dictionary and returns the translation
	
	if (langs[key]&& langs[key][lang] ) {
		return langs[key][lang];
		}
	else {
		return key;
	}
}



$( document ).ready(function() { //translate when everything is loaded(the page is ready)
    function translate_all(lang){
		$(".translatable").each(function(){
			$(this).html(get_translation(lang, $(this).data("key")));
		});
		
	}
	$("body").on("click",".translate",function(){ // translate when the language buttons are clicked. 
		var lang = $(this).data("lang");
		translate_all(lang);
		localStorage.setItem("lang",lang);
        window.location.reload(); //Elsa: This is to be able to translate javascript files.
	});
	var defaultLang = localStorage.getItem("lang");
	if (!defaultLang){ //set a default lang
		defaultLang = "en"
	}
	translate_all(defaultLang);
});